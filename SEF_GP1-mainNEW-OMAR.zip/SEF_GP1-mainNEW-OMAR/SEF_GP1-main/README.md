# SEF_GP1
Software Engineering Fundemental Group 1

All updates to the code should be uploaded here. Dont update the code here if the updated code have a bug or broken, this sould only be for working codes
