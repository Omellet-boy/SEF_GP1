#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QChart>
#include <QGroupBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QProgressBar>
#include <QPushButton>
#include <QStackedWidget>
#include "simulator.h"
#include "database.h"
#include "solar_monitoring_page.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void setDatabase(Database *db);

private slots:
    void updateDashboard();

private:
    // Core components (unchanged)
    Simulator *simulator;
    Database *database = nullptr;

    // Navigation (unchanged)
    QWidget *navWidget;
    QVBoxLayout *navLayout;
    QPushButton *dashboardButton;
    QPushButton *settingsButton;
    QPushButton *batteryMonitoringButton;
    QPushButton *solarMonitoringButton;
    QPushButton *dataManagementButton;

    // Pages (only added SolarMonitoringPage*)
    QWidget *dashboardPage;
    QStackedWidget *stackedWidget;
    SolarMonitoringPage* solarPage;  // Your dedicated solar page pointer

    // Central widget (unchanged)
    QWidget *centralWidget;

    // Dashboard widgets (all unchanged)
    QProgressBar *modernBatteryBar;
    QLabel *modernBatteryLabel;
    QLabel *modernDegradationLabel;
    QLabel *modernTempLabel;
    QLabel *modernSolarLabel;
    QChartView *modernBarChartView;

    QGroupBox *createSolarPanelGroup();
    QLabel *solarPowerLabel;
    QLabel *loadLabel;
    QLabel *netLabel;

    QGroupBox *createBatteryGroup();
    QProgressBar *batteryBar;
    QLabel *batteryPercentLabel;

    QGroupBox *createSimulationInfoGroup();
    QLabel *timeLabel;
    QLabel *weatherLabel;

    QChartView *powerChartView;
    QLineSeries *powerSeries;
    QChart *powerChart;
    int chartX;
    QString currentDay;

    // Methods (unchanged)
    QWidget* createModernDashboardPage();
    void setupPowerChart();
    void resetGraphForNewDay();
};

#endif // MAINWINDOW_H
